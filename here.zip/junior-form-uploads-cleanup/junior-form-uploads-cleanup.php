<?php
/**
 * Plugin Name: Junior — nettoyage des fichiers de formulaire
 * Description: Usage unique. Liste puis supprime les fichiers envoyés via l'ancien formulaire Elementor (wp-content/uploads/elementor/forms/). À supprimer après usage.
 * Version:     1.0.0
 * Requires PHP: 8.0
 */

defined('ABSPATH') || exit;

final class Junior_Form_Uploads_Cleanup
{
    // index.php is WordPress's guard against directory listing: keep it.
    const KEEP = ['index.php', 'index.html', '.htaccess'];

    public static function boot(): void
    {
        add_action('admin_menu', fn () => add_management_page('Fichiers de formulaire', 'Fichiers de formulaire', 'manage_options', 'junior-form-cleanup', [self::class, 'render']));
        add_action('admin_post_junior_form_cleanup', [self::class, 'handle_delete']);
    }

    private static function folder(): string
    {
        return trailingslashit(wp_get_upload_dir()['basedir']) . 'elementor/forms';
    }

    /** @return list<string> absolute paths of uploaded files */
    private static function files(): array
    {
        if (!is_dir(self::folder())) {
            return [];
        }
        $files = [];
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator(self::folder(), FilesystemIterator::SKIP_DOTS));
        foreach ($it as $file) {
            if ($file->isFile() && !in_array($file->getFilename(), self::KEEP, true)) {
                $files[] = $file->getPathname();
            }
        }
        sort($files);
        return $files;
    }

    public static function render(): void
    {
        $files = self::files();
        echo '<div class="wrap"><h1>Fichiers envoyés via l’ancien formulaire</h1>';
        echo '<p>Dossier : <code>' . esc_html(self::folder()) . '</code></p>';
        if (isset($_GET['deleted'])) {
            echo '<div class="notice notice-success"><p>' . esc_html((int) $_GET['deleted']) . ' fichier(s) supprimé(s). Vous pouvez maintenant désactiver et supprimer cette extension.</p></div>';
        }
        if (!$files) {
            echo '<p><strong>Aucun fichier à supprimer.</strong> Désactivez puis supprimez cette extension.</p></div>';
            return;
        }
        echo '<p>Ces fichiers sont accessibles publiquement. Téléchargez ceux que vous devez conserver avant de les supprimer : la suppression est <strong>définitive</strong>.</p>';
        echo '<table class="widefat striped" style="max-width:60em"><thead><tr><th>Fichier</th><th>Date</th><th>Taille</th></tr></thead><tbody>';
        $base = trailingslashit(wp_get_upload_dir()['baseurl']) . 'elementor/forms/';
        foreach ($files as $path) {
            $relative = ltrim(substr($path, strlen(self::folder())), '/');
            printf('<tr><td><a href="%s" target="_blank" rel="noopener">%s</a></td><td>%s</td><td>%s</td></tr>',
                esc_url($base . $relative), esc_html($relative), esc_html(wp_date('d/m/Y H:i', filemtime($path))), esc_html(size_format(filesize($path))));
        }
        echo '</tbody></table>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '" onsubmit="return confirm(\'Supprimer définitivement ' . count($files) . ' fichier(s) ?\')">';
        wp_nonce_field('junior_form_cleanup');
        echo '<input type="hidden" name="action" value="junior_form_cleanup">';
        submit_button('Supprimer définitivement ces ' . count($files) . ' fichier(s)', 'delete');
        echo '</form></div>';
    }

    public static function handle_delete(): void
    {
        if (!current_user_can('manage_options')) {
            wp_die('Accès refusé.', 403);
        }
        check_admin_referer('junior_form_cleanup');
        $deleted = 0;
        foreach (self::files() as $path) {
            if (@unlink($path)) {
                $deleted++;
            }
        }
        wp_safe_redirect(admin_url('tools.php?page=junior-form-cleanup&deleted=' . $deleted));
        exit;
    }
}

Junior_Form_Uploads_Cleanup::boot();
